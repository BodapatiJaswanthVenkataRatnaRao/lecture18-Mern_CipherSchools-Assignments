var counter = (arr) => {
    return "this array has " + arr.length + " elements"
};
// addition(2,4)
var addition = (a,b) => {
    return `the sum is ${a+b}`
}

const constant = 9.4561;
module.export.counter = counter;
module.export.addition = addition;
module.export.constant = constant;

