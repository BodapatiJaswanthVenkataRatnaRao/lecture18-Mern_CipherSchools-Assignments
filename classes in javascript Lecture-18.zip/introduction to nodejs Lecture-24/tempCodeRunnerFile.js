const constant = 9.4561;
module.export.counter = counter;
module.export.addition = addition;
module.export.constant = constant;
