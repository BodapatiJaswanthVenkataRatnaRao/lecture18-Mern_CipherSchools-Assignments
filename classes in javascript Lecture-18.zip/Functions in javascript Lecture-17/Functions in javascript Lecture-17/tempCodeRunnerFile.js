let function3 = (name) => {
    consol.log(name)
}
function3(name);